ispell-lt
=========

You are looking at the dictionaries and affix files for spellchecking
of Lithuanian texts.

The latest version of the affix tables and dictionaries can be found
at https://launchpad.net/ispell-lt .  The mailing list of the project
is available at https://lists.akl.lt/mailman/listinfo/ispell-lt .
Bazaar is used for version control and it is available at
https://code.launchpad.net/~ispell-lt/ispell-lt/trunk .

The software is available under the provisions of a BSD-style license.
The full text of the license is available in the COPYING file.

The project has been sponsored by the Information Society Development
Committee of the Government of Republic of Lithuania.

Albertas Agejevas <alga@akl.lt>
