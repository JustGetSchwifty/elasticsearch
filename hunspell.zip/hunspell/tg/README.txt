Tajik Hunspell Dictionary.

Tajik Hunspell Dictionary is organized on the basis of Apache License Version 2.0, January 2004 http://www.apache.org/licenses/

Tajik Hunspell Dictionary is generated as a result of research work of representatives of Public organization «Center of development of information technologies Zafar Usmanov» and financial support of Institute of the Open Society in Tajikistan in 2014.

Version 1.0.0

The baggage of Tajik Hunspell Dictionary makes from 69 000 lexical units (prefixes, roots, postfixes). The dictionary including 79 prefixes, 63571 roots and 2791 postfixes. The dictionary provides possibility of generating of the Tajik words (by word-formation and word change) exclusively enormous volume preliminary estimated rather of 7 million of words.

The maintenance of Tajik Hunspell Dictionary are received by basis of results of long-term scientifically research works of the Tajik scientists in the field of computer linguistics the doctor of physical and mathematical sciences, professor Usmanov Zafar, candidates of physical and mathematical sciences Soliev Odil, Khudoyberdiev Khurshed, Dovudov Gulshan.

The Tajik Hunspell Dictionary can be used for a possibility of correct spelling of texts in the Tajik language in office programs such as OpenOffice, LibreOffice and Internet browsers such as Mozila FireFox, Opera, Google Chrome. As a whole the dictionary can be used for expansion of possibilities of other software and information systems which support and work with HunSpell standard.

If other is not established in writing, the legal owner and-or other parties give dictionary Tajik Hunspell Dictionary «as is», without what or guarantees (declared or meant), including, but, not being limited, meant guarantees of a commodity condition at sale and the validity for certain application. All risk as concerning quality, and productivity of the dictionary you incur. If in the dictionary defect is found out, you incur cost of necessary service or correction repairing.

Dictionary Tajik Hunspell Dictionary is accessible in Internet network here http://www.tajlingvo.tj\project\tajikHunSpellDictionary

In case of detection of lacks and \or defects in theTajik Hunspell Dictionary, and also for your granting of the offers and remarks can you will address to dictionary developers to E-mail address info@tajlingvo.tj or  tajlingvo@gmail.com .
