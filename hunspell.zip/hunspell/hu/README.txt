This word collection contains 1.01 million words of the Hungarian language. Since it avoids automatic compound words building, its error rate is below 0.5%, as opposite to the 10% error rate of the machine compounding word collection. See also http://tkltrans.sf.net/tklspell/compound.htm#c01  about machine compounding.
This word collection is on http://tkltrans.sourceforge.net/tklspell/hu_HU_comb.zip
The building tree is on:
http://tkltrans.sourceforge.net/tklspell/hu_HU_tree.tar.gz

Suggestions, wishes to eleonora46_at_gmx_dot_net


Hungarian:
Ez a sz�gy�jtem�ny 1.02 milli� magyar sz�t tartalmaz. Mivel nem k�pez g�pi �ton �sszetett szavakat, hibaar�nya 0.5% alatt van, szemben a 10%-os hibaar�nnyal dolgoz� g�pi �sszetett sz�k�pz� v�ltozattal. L�sd a http://tkltrans.sf.net/tklspell/compound.htm#c01 cikket a g�pi �sszetettsz�-k�pz�sr�l. 
Ez a sz�gy�jtem�ny megtal�lhat�: http://tkltrans.sourceforge.net/tklspell/hu_HU_comb.zip c�men.
A szavak f�ja �s a sz�ks�ges programok haszn�lati utas�t�ssal: 
http://tkltrans.sourceforge.net/tklspell/hu_HU_tree.tar.gz c�m alatt tal�lhat�k. 

Javaslatok, k�v�ns�gok  eleonora46_kukac_gmx_pont_net c�mre k�ldhet�k.
