﻿Comment of the extension owner
==============================

* In a test of an available dedicated Latin hyphenation module, problems appeared in compliance with compound words. It seemed therefore better to use the Italian hyphenation module renamed to "hyph_la.dic". Of course, I know that the rules for Italian and Latin hyphenation are not (quiet) the same.
Prefering an original Latin hyphenation dictionary for LibreOffice or OpenOffice.org, feel free to use it. Copy the corresponding module in the hyph_la folder. Make sure that the alternative module has the same name as the supplied module and that it is encoded as Unix UTF-8.

* The Latin spelling dictionary 3.1 has been considerably improved. For detailed information read the readme files. Your comment is wellcome. Detecting errors or missing words, please contact the author via e-mail.
For contacting the Author: karl<point>zeiler<at>t-online.de

* An extension update is intended to be published, as soon the dictionary will have been actualized.

For contacting the extension owner write to:
karl<point>zeiler<at>t-online.de