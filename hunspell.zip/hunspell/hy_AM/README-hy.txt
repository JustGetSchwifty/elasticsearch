*********************************
* README_hy_AM	*
*********************************

Hunspell Armenian dictionary
language: Armenian (Հայերեն)
locale: hy_AM
copyright GPL
Used wordlist from aspell Armenian dictionary package : 
See original package:  ftp://ftp.gnu.org/gnu/aspell/dict/hy/aspell6-hy-0.10.0-0.tar.bz2 Version 0.10.0-0  2007-02-26  Alan Baghumian.
***********************************
Cleanup and converting from simple wordlist to prefix/affix based dictionary. Removing words written with old orphography. Some minor additions to wordlist. Done by Aleksey Chalabyan a.k.a. Xelgen  < xelgen-am at gmail com >

Andranik Markosyan < andranik at gmail com >
