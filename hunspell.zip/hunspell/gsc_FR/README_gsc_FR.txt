Corrector ortografic occitan-gascon ent� OpenOffice h�it per Patric Guilhemjoan dab l'ajuda de Michel Turck ent� l'extension e lo desvolopament informatics de la partida ling�istica e Laurent Godard (Nuxeo/InDesko <lgodard@indesko.com>) ent� l'afixacion e l'integracion a OpenOffice.org.

Aqueste logiciau qu'est� desvolopat sus la basa deu Dictionnaire fran�ais-occitan (gascon) de Michel Grosclaude, Patric Guilhemjoan e Gilab�rt Nari�o publicat a las edicions Per Noste.
Las edicions Per Noste que son propriet�rias deus drets de lic�ncia deu present corrector e qu'autorizan lo son emplec segon los  t�rmes de la lic�ncia Creative Commons BY-NC-ND
http://creativecommons.org/licenses/by-nc-nd/2.0/fr/

Aqueste corrector ortografic qu'est� parciaument finan�at merc�s a ua ajuda deu Conselh generau deus -Piren�us Hauts.

Per Noste
7, avienuda Francis Jammes
64 300 Ort�s
pernoste@wanadoo.fr
www.pernoste.com
tel. 05 59 67 07 11
fax 05 59 69 49 30

Correcteur orthographique occitan-gascon pour OpenOffice.org r�alis� par Patric Guilhemjoan, avec l'aide de Michel Turck pour l'extension et le d�veloppement informatique de la partie linguistique et Laurent Godard (Nuxeo/InDesko <lgodard@indesko.com>)  pour l'affixation et l'int�gration � OpenOffice.org.

Ce logiciel a �t� d�velopp� sur la base du Dictionnaire fran�ais-occitan (gascon) de Michel Grosclaude, Patric Guilhemjoan et Gilab�rt Nari�o publi� aux �ditions Per Noste.
Les �ditions Per Noste sont propri�taires des droits de licence du pr�sent correcteur et autorisent son utilisation selon les termes de la licence Creative Commons BY-NC-ND
http://creativecommons.org/licenses/by-nc-nd/2.0/fr/

Ce correcteur orthographique a �t� partiellement financ� gr�ce � une aide du Conseil g�n�ral des Hautes-Pyr�n�es.

Per Noste
7, avenue Francis-Jammes
64 300 Orthez
tel. 05 59 67 07 11
fax 05 59 69 49 30
pernoste@wanadoo.fr
http://www.pernoste.com

