OpenOffice dictionary
----------------------

Language: Croatian (hr HR).
License:  LGPL/SISSL license, 2003
Author:   delacko@linux.hr (Denis Lackovic)


