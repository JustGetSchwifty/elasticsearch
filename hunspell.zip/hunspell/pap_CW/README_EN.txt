README_EN.txt
14-09-2011
********************************************************************************
Name: Papiamento word list - Foundation Curacao Open
Version: 1.00
Format: Hunspell

Copyright owners and history
--------------------------------------------------------------------------------
(c) 2009 Suares & Co, FPI
First Official Release

Licenses:
--------------------------------------------------------------------------------
This word list is derived from the official list of words in the language
Papiamentu, as composed by FPI. 

This work is licensed under the
Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License.
To view a copy of this license,
visit http://creativecommons.org/licenses/by-nc-sa/3.0/
or send a letter to Creative Commons, 444 Castro Street, Suite 900,
Mountain View, California, 94041, USA.

This is version 1.00 of this word list. It is derived from version 20110917
of the original work. 
This work will be superseded by any newer version of this work.

You are kindly requested to keep a copy of this file 
"README_EN.txt" with every copy you make of the word list.

More information: http://opencuracao.com


