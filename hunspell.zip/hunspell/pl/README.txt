English:
========

This dictionary for spell-checking Polish texts is licensed under
GPL, LGPL, MPL (Mozilla Public License), Apache 2.0 and Creative Commons
ShareAlike licenses (see http://creativecommons.org/licenses/sa/1.0).

This version of the dictionary was generated on 2014-07-16
The most up-to-date version can be found at:
http://www.sjp.pl/slownik/en/

Dictionary maintainer: Marek Futrega (futrega@gmail.com)


Polski:
=======

Niniejszy slownik do sprawdzania pisowni jest udostepniany na licencjach
GPL, LGPL, MPL (Mozilla Public License), Apache 2.0 i Creative Commons
ShareAlike (zobacz http://creativecommons.org/licenses/sa/1.0).

Data utworzenia tej wersji slownika: 2014-07-16
Najnowsza wersje mozna pobrac ze strony:
http://www.sjp.pl/

Opiekun slownika: Marek Futrega (futrega@gmail.com)

