
	Russian Hunspell dictionary

Автор:
	Александр Клюквин (https://sites.google.com/site/dictru/)
Сайт проекта:
	http://code.google.com/p/hunspell-ru/

