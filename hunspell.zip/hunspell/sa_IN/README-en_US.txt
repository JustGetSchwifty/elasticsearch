+------------------------+
| SANSKRIT SPELL CHECKER |
+------------------------+

Author: Adriana Quintanilha <belacine@gmail.com>
	Vinícius Della Líbera <artedogesto@gmail.com>

This dictionary is under development by Adriana Quintanilha and Vinícius Della Líbera. It is 
licensed under the terms of the GNU Lesser General Public License version 2.1(LGPLv2.1),
as published by the Free Software Foundation.


Copyright (C) 2011 by Adriana Quintanilha and Vinícius Della Líbera.

+--------------+
| INTRODUCTION |
+--------------+

The Sanskrit Spell Checker Collaborative is a project developed by a Brazilian.
We need help to improve this list and increase employees.

If this project has been useful to you, please consider making a donation. Contact belacine@gmail.com


+-----------+
| CHANGELOG |
+-----------+

Please see the file Changelog-en_US.txt

