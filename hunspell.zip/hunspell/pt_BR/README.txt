Author: Raimundo Moura <raimundomoura@openoffice.org>

en-US: This dictionary is under continuous development by Raimundo Moura and his team. It is 
licensed under the terms of the GNU Lesser General Public License version 3 (LGPLv3),
as published by the Free Software Foundation, and Mozilla Public License as published by 
The Mozilla Foundation.  The credits are available at 
http://pt-br.libreoffice.org/projetos/projeto-vero-verificador-ortografico/ and you can 
find new releases at 
http://extensions.libreoffice.org

Copyright (C) 2006 - 2012 by Raimundo Santos Moura <raimundo.smoura@gmail.com>

============
INTRODUCTION
============

The LibreOffice Spell Checker and Hyphenation  is a colaborative project developed
by the Brazilian community.
The complete list of participants in this project is at
http://pt-br.libreoffice.org/projetos/projeto-vero-verificador-ortografico/

***********************************************************************
* This is a dictionary for spell correction and hyphenation for the   *
* Brazilian Portuguese language for hunspell.                         *
* This is a free program and it can be redistributed and/or           *
* modified under the terms of the GNU Lesser General Public License   *
* (LGPL) version 3 and Mozilla Public License.                        *
*                                                                     *
***********************************************************************
