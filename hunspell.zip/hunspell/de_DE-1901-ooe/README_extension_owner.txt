Comment of the extension owner

This extension (version 2014-02-21) is based on:

Spell checking (old spelling)
=============================
Author
(C) 2014 R�diger Br�nner (Version: 2014-02-14)
derived from igerman98 and frami dictionaries:

Copyright 
(C) 1998-2013 Bjoern Jacke <bjoern@j3e.de> 
(C) 1998-2013 Franz Michael Baumann <frami.baumann@web.de>

Modified according to the classical spelling rules
with a lot of corrections and supplements by
(C) 2010-2014 R�diger Br�nner (Version: 2014-02-14)
License: GNU General Public License (GPL v. 2 or 3)

Hypenation (old spelling)
=========================
http://de.openoffice.org/spellcheck/about-spellcheck-detail.html#dicooo
Author: Marco Huggenberger<marco@by-night.ch> / Daniel Naber
Version: 2014-02-21
Enhanced blacklist by Karl Zeiler to improve the hyphenation module
License: GNU Lesser General Public License (LGPL)

Thesaurus (new spelling)
========================
OpenThesaurus - Deutscher Thesaurus - Synonyme und Assoziationen
Version: 2014-02-15
License: GNU LGPL 2.1
http://www.openthesaurus.de

Please note
===========
Detecting errors or missing words, please contact the extension owner:
karl<point>zeiler<at>t-online.de