N  	prefix ne
Z 	žena – množné číslo
z 	žena-iba jednotné číslo (napr. látkové podst. mená-ropa, názvy jazykov-slovenčina prípadne ďalšie veci, pre ktoré sa nepoužíva množné číslo…
U 	ulica
D 	dlaň
K 	kosť
M 	mesto
S 	srdce
V 	vysvedčenie
A 	dievča
C 	chlap v nominatíve plurálu s -i (+hosť)
c       chlap a kuli v nominatíve plurálu s -ia (okrem hosť)
H 	hrdina
B 	vzor dub
b	vzor dub, kde v Genitíve Singuláru je -u a v lokále -e 
o	vzor dub, kde v Genitíve Singuláru je -a a v lokále -i<F11>
O 	dub – zámen hlások v koncovke (výrobok, zárodok, výstrižok)
J 	stroj
L 	zvieracie podstatné mená mužského rodu (capko -> -ovia; nerobí dvojtvary -y/-ovia)
Q 	pomnožné
Y 	prídavné mená – všetky, kt. nie sú zakončené na -í + podstatné mená, ktoré sa ohýbajú ako prídavné mená (chyžná, gazdiná, skladné ...)
I 	prídavné mená zakončené na -í
F 	stupňovanie prídavných mien – 3. stupeň
P 	stupňovanie prídavných mien – 2. stupeň
X 	slovesá podľa vzorov chytať, robiť s krátkou koncovkou
E 	slovesá podľa vzorov chytať, robiť s dlhou koncovkou
W 	slovesá podľa vzorov pracovať
T 	slovesá podľa vzorov česať
R 	slovesá podľa vzorov kričať, brať
č	násobky pre číslovky
